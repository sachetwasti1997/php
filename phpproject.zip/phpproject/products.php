<!DOCTYPE php>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>login</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="index.css" type="text/css">
    </head>
    <body>
       <nav class="navbar navbar-inverse navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>                        
                    </button>
                    <a class="navbar-brand" href="index.php">Lifestyle Store</a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav navbar-right">
                         <li><a href="cart.php"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li>
                        <li><a href="settings.php"><span class="glyphicon glyphicon-user"></span>Settings</a></li>
                        <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
                       
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container">
            <div class="jumbotron">
                <h1>Welcome to our Lifestyle Store</h1>
                <p>We have the best cameras, watches and shirts for you. No need to hunt
around, we have all in one place.</p>
            </div>
            <div class=" row text-center">
                <div class="col-md-3 col-sm-6">
                    <div class="thumbnail">
                            <img src="camera.jpg" alt="">
                            <div class="caption">
                                <h3>Cameras</h3>
                                <p>Choose among the best available in the world.</p>
                            </div>
                            <button class="btn btn-primary" style=" width: 100%">Add to Cart</button>
                        </div> 
                    
                              </div>
                 <div class="col-md-3 col-sm-6">
                    <div class="thumbnail">
                            <img src="camera.jpg" alt="">
                            <div class="caption">
                                <h3>Cameras</h3>
                                <p>Choose among the best available in the world.</p>
                            </div>
                            <button class="btn btn-primary" style=" width: 100%">Add to Cart</button>
                        </div> 
                    
                              </div>
                 <div class="col-md-3 col-sm-6">
                    <div class="thumbnail">
                            <img src="camera.jpg" alt="">
                            <div class="caption">
                                <h3>Cameras</h3>
                                <p>Choose among the best available in the world.</p>
                            </div>
                            <button class="btn btn-primary" style=" width: 100%">Add to Cart</button>
                        </div> 
                    
                              </div>
                 <div class="col-md-3 col-sm-6">
                    <div class="thumbnail">
                            <img src="camera.jpg" alt="">
                            <div class="caption">
                                <h3>Cameras</h3>
                                <p>Choose among the best available in the world.</p>
                            </div>
                            <button class="btn btn-primary" style=" width: 100%">Add to Cart</button>
                        </div> 
                    
                              </div>
        </div>
             <div class=" row text-center">
                <div class="col-md-3 col-sm-6">
                    <div class="thumbnail">
                            <img src="watch.jpg" alt="">
                            <div class="caption">
                                <h3>Watches</h3>
                                <p>Choose among the best available in the world.</p>
                            </div>
                            <button class="btn btn-primary" style=" width: 100%">Add to Cart</button>
                        </div> 
                    
                              </div>
                 <div class="col-md-3 col-sm-6">
                    <div class="thumbnail">
                            <img src="watch.jpg" alt="">
                            <div class="caption">
                                <h3>Watches</h3>
                                <p>Choose among the best available in the world.</p>
                            </div>
                            <button class="btn btn-primary" style=" width: 100%">Add to Cart</button>
                        </div> 
                    
                              </div>
                 <div class="col-md-3 col-sm-6">
                    <div class="thumbnail">
                            <img src="watch.jpg" alt="">
                            <div class="caption">
                                <h3>Watches</h3>
                                <p>Choose among the best available in the world.</p>
                            </div>
                            <button class="btn btn-primary" style=" width: 100%">Add to Cart</button>
                        </div> 
                    
                              </div>
                 <div class="col-md-3 col-sm-6">
                    <div class="thumbnail">
                            <img src="watch.jpg" alt="">
                            <div class="caption">
                                <h3>Watches</h3>
                                <p>Choose among the best available in the world.</p>
                            </div>
                            <button class="btn btn-primary" style=" width: 100%">Add to Cart</button>
                        </div> 
                    
                              </div>
        </div>
            <div class=" row text-center pr">
                <div class="col-md-3 col-sm-6">
                    <div class="thumbnail">
                            <img src="shirt.jpg" alt="">
                            <div class="caption">
                                <h3>Shirts</h3>
                                <p>Choose among the best available in the world.</p>
                            </div>
                            <button class="btn btn-primary" style=" width: 100%">Add to Cart</button>
                        </div> 
                    
                              </div>
                 <div class="col-md-3 col-sm-6">
                    <div class="thumbnail">
                            <img src="shirt.jpg" alt="">
                            <div class="caption">
                                <h3>Shirts</h3>
                                <p>Choose among the best available in the world.</p>
                            </div>
                            <button class="btn btn-primary" style=" width: 100%">Add to Cart</button>
                        </div> 
                    
                              </div>
                 <div class="col-md-3 col-sm-6">
                    <div class="thumbnail">
                            <img src="shirt.jpg" alt="">
                            <div class="caption">
                                <h3>Shirts</h3>
                                <p>Choose among the best available in the world.</p>
                            </div>
                            <button class="btn btn-primary" style=" width: 100%">Add to Cart</button>
                        </div> 
                    
                              </div>
                 <div class="col-md-3 col-sm-6">
                    <div class="thumbnail">
                            <img src="shirt.jpg" alt="">
                            <div class="caption">
                                <h3>Shirts</h3>
                                <p>Choose among the best available in the world.</p>
                            </div>
                            <button class="btn btn-primary" style=" width: 100%">Add to Cart</button>
                        </div> 
                    
                              </div>
        </div>
           
        </div>
        
         <footer class="foot">
            <div class="container">
                    <center>
                Copyright © Lifestyle Store. All Rights
Reserved and Contact Us: +91 90000 00000
            </center>
            </div>
        
        </footer>
                   
    </body>
</html>
