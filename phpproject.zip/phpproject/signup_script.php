
<?php
$con = mysqli_connect("localhost:3307", "root", "root", "store") or die(mysqli_error($con));
$name=$_POST['name'];
$email = $_POST['email'];
$password = md5($_POST['pass']);
$contact=$_POST['contact'];
$city=$_POST['city'];
$select_query = "SELECT email FROM users_items";
$select_query_result = mysqli_query($con, $select_query) or die(mysqli_error($con));
$row = mysqli_fetch_array($select_query_result);
$user_registration_query = "insert into users_items(name,email, password,contact,city) values ('$name','$email', '$password','$contact','$city')";
$user_registration_submit = mysqli_query($con, $user_registration_query) or die(mysqli_error($con));

$total_rows_fetched = mysqli_num_rows($select_query_result);
echo $total_rows_fetched;
?>