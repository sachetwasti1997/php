<?php
$con= mysqli_connect("localhost:8889", "root","","store") or die(mysqli_error($con));
session_start();
echo " you are connected as session has started";


?>