
 <?php
//include 'includes/common.php';
  if (isset($_SESSION['email']))
 { header('location: products.php'); }
?> 

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Signup</title>
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="index.css" type="text/css">
    </head>
    <body>
       <?php
       include 'includes/header.php';
       ?>
        <div class="mgh panel panel-default">
                        <div class="panel-heading">
                            <h1> SignUp Form</h1> 
                        </div>
            <div class="panel-body">
                <form method="POST" action="signup_script.php">
                <div class="form-group">
             <input type="text" id="name" class="form-control" placeholder="name" ><br>
             <input type="text" id="email" class="form-control" placeholder="your email" ><br>
             <input type="password" id="pass" class="form-control" placeholder="password" ><br>
             <input type="numbers" id="contact" class="form-control" placeholder="contact number" ><br>
             <input type="text" id="city" class="form-control" placeholder="city" ><br>
             <button class="btn btn-primary" value=”signup_submit”>submit</button>
            </div>
                </form>
            </div>
         
        </div>
       <?php
       include 'includes/footer.php';
       ?>
    </body>
</html>
