
<?php 
//require 'includes/common.php';
if (isset($_SESSION['email']))
    { header('location: products.php'); }
?>
<!DOCTYPE php>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>login</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="index.css" type="text/css">
    </head>
    <body>
       <nav class="navbar navbar-inverse navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>                        
                    </button>
                    <a class="navbar-brand" href="index.php">Lifestyle Store</a>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="signup.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
                        <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class=" mgh panel panel-default">
                        <div class="panel-heading">
                            <h4>Login Form</h4>
                        </div>
                        <div class="panel-body">
                            <form method="POST" action="login_submit.php">
                            <p class="text-warning">Login to make a purchase</p>
                            <div class="form-group">
                <label for="email">Your Email Id</label>
                <input type="text" id="email" class="form-control" placeholder="your email" >
            </div>
         <div class="form-group">
             <label for="pass">Password</label>
                <input type="password" id="pass" class="form-control" placeholder="your password"  >
                        </div>
                            <button class="btn btn-primary" value=”login_submit”>submit details</button>
                            </form>
                        </div>
                        </div>
        <div class="panel-footer"><center> Don't have an account?<a href="signup.php"> Register</a></center></div>
        <?php
        include 'includes/footer.php';
        
        ?>
    </body>
</html>
