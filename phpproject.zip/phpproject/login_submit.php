<?php 
require 'includes/common.php';
$con = mysqli_connect("localhost:8889", "root", "", "store") or die(mysqli_error($con));
$email = $_POST['email'];
$password = md5($_POST['pass']);
$user_registration_query = "insert into users(email, password) values ('$email', '$password')";
$user_registration_submit = mysqli_query($con, $user_registration_query) or die(mysqli_error($con));
$total_rows_fetched = mysqli_num_rows($select_query_result);
echo $total_rows_fetched;
if($total_rows_fetched>0){
    $con = mysqli_connect("localhost:8889", "root", "", "ecommerce") or die(mysqli_error($con));
$select_query = "SELECT email,password FROM users";
$select_query_result = mysqli_query($con, $select_query) or die(mysqli_error($con));
$row = mysqli_fetch_array($select_query_result);
echo $row['email']."<br/>";
echo $row['password'];
$_SESSION['email'] = $email;
$_SESSION['id'] = mysqli_insert_id($con);
header('location: products.php');
}





?>